from ansible.plugins.inventory import BaseInventoryPlugin

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'Richemont'
}

DOCUMENTATION = '''
---
module: datadog
plugin_type: inventory
short_description: An example Ansible Inventory Plugin to test datadog
version_added: "2.9.13"
description:
    - "A very simple Inventory Plugin created for demonstration purposes only."
options:
author:
    - Stuart Stafford
'''

class InventoryModule(BaseInventoryPlugin):
    """An example inventory plugin."""

    NAME = 'datadog.custom_env.datadog_example'

    def verify_file(self, path):
        """Verify that the source file can be processed correctly.

        Parameters:
            path:AnyStr The path to the file that needs to be verified

        Returns:
            bool True if the file is valid, else False
        """
        # Unused, always return True
        return True

    def _get_raw_host_data(self):
        """Get the raw static data for the inventory hosts

        Returns:
            dict The host data formatted as expected for an Inventory Script
        """
        return {
            "all": {
                "hosts": ["dtccmsbempubd61.dtc.rccad.net", "dtccmsbempubd62.dtc.rccad.net"]
            },
            "stuart_test": {
              "hosts": [
                "dtccmsbempubd61.dtc.rccad.net",
                "dtccmsbempubd62.dtc.rccad.net"
              ],
              "vars": {
                "application": "stuart_test"
              },
              "children": []
            },
            "_meta": {
                "hostvars": {
                    "dtccmsbempubd61.dtc.rccad.net": {
                        "http_proxy": "http://zproxy-euc1.eu.aws.rccad.net:80",
                        "https_proxy": "http://zproxy-euc1.eu.aws.rccad.net:80",
                        "test": "test123"
                    },
                    "dtccmsbempubd62.dtc.rccad.net": {
                        "http_proxy": "http://zproxy-euc1.eu.aws.rccad.net:80",
                        "https_proxy": "http://zproxy-euc1.eu.aws.rccad.net:80",
                        "test": "test123"
                    }
                }
            }
        }

    def parse(self, inventory, *args, **kwargs):
        """Parse and populate the inventory with data about hosts.

        Parameters:
            inventory The inventory to populate

        We ignore the other parameters in the future signature, as we will
        not use them.

        Returns:
            None
        """
        # The following invocation supports Python 2 in case we are
        # still relying on it. Use the more convenient, pure Python 3 syntax
        # if you don't need it.
        super(InventoryModule, self).parse(inventory, *args, **kwargs)

        raw_data = self._get_raw_host_data()
        _meta = raw_data.pop('_meta')
        for group_name, group_data in raw_data.items():
            for host_name in group_data['hosts']:
                self.inventory.add_host(host_name)
                for var_key, var_val in _meta['hostvars'][host_name].items():
                    self.inventory.set_variable(host_name, var_key, var_val)
